clc;clear;close all;
tic;
correct=0;

num_0=imread('.\numbers\0.jpg');
num_1=imread('.\numbers\1.jpg');
num_2=imread('.\numbers\2.jpg');
num_3=imread('.\numbers\3.jpg');
num_4=imread('.\numbers\4.jpg');
num_5=imread('.\numbers\5.jpg');
num_6=imread('.\numbers\6.jpg');
num_7=imread('.\numbers\7.jpg');
num_8=imread('.\numbers\8.jpg');
num_9=imread('.\numbers\9.jpg');

num_0_small=imread('.\numbers\0_small.jpg');
num_1_small=imread('.\numbers\1_small.jpg');
num_2_small=imread('.\numbers\2_small.jpg');
num_3_small=imread('.\numbers\3_small.jpg');
num_4_small=imread('.\numbers\4_small.jpg');
num_5_small=imread('.\numbers\5_small.jpg');
num_6_small=imread('.\numbers\6_small.jpg');
num_7_small=imread('.\numbers\7_small.jpg');
num_8_small=imread('.\numbers\8_small.jpg');
num_9_small=imread('.\numbers\9_small.jpg');

for i=0:9
    eval([strcat('num_',num2str(i),'_45') '= convert_to_0_1(cropping(imrotate(' strcat('num_',num2str(i)) ',45)));']);
    eval([strcat('num_',num2str(i),'_small_45') '= convert_to_0_1(cropping(imrotate(' strcat('num_',num2str(i),'_small') ',45)));']);

    eval([strcat('num_',num2str(i),'_45m') '= convert_to_0_1(cropping(imrotate(' strcat('num_',num2str(i)) ',-45)));']);
    eval([strcat('num_',num2str(i),'_small_45m') '= convert_to_0_1(cropping(imrotate(' strcat('num_',num2str(i),'_small') ',-45)));']);
end

for x=0:99
    I=imread(['.\Dataset\Images\im_' num2str(x) '.png']);
    for i=1:size(I,1)
        for j=1:size(I,2)
            if I(i,j,1)==255 || (I(i,j,2)==255 && I(i,j,3)==255)
                I(i,j,:)=[0,0,0];
            end
        end
    end
    I=I(:,:,3);
    
    points=[];
    
    for row=1:size(I,1)
        for colomn=1:size(I,2)
            if I(row,colomn)==255
                image=I;
                
                subimage=image(row:min([row+100,size(I,1)]),max([colomn-50,1]):min([colomn+50,size(I,2)]));
    
    
                subimage=cropping(subimage);
            
                mainNorm=100000;
            
                for i=0:9
                    if size(subimage,1)>35
                        eval(['arr = abs(subimage - convert_to_0_1(imresize(' strcat('num_',num2str(i)) ',size(subimage))));']);
                        norm1=sum(sum(arr,2),1);
        
                        eval(['arr = abs(subimage - convert_to_0_1(imresize(' strcat('num_',num2str(i),'_45') ',size(subimage))));']);
                        norm2=sum(sum(arr,2),1);
        
                        eval(['arr = abs(subimage - convert_to_0_1(imresize(' strcat('num_',num2str(i),'_45m') ',size(subimage))));']);
                        norm3=sum(sum(arr,2),1);
                    else
                        eval(['arr = abs(subimage - convert_to_0_1(imresize(' strcat('num_',num2str(i),'_small') ',size(subimage))));']);
                        norm1=sum(sum(arr,2),1);
                
                        eval(['arr = abs(subimage - convert_to_0_1(imresize(' strcat('num_',num2str(i),'_small_45') ',size(subimage))));']);
                        norm2=sum(sum(arr,2),1);
                    
                        eval(['arr = abs(subimage - convert_to_0_1(imresize(' strcat('num_',num2str(i),'_small_45m') ',size(subimage))));']);
                        norm3=sum(sum(arr,2),1);
                    end
    
                    norm=min([norm1,norm2,norm3]);
                    if norm < mainNorm
                        mainNorm = norm;
                        number = i;
                    end
                end
            
                zeroImage = zeros(101,101);
                I(row:row+100,colomn-50:colomn+50) = zeroImage;
    
                points=[points; [number,row,colomn]];
            end
        end
    end
    correct=iscorrect(points,x,correct);
end

disp(['correct image: ' num2str(correct)]);
toc;
function img = convert_to_0_1(img)
    for i=1:size(img,1)
        for j=1:size(img,2)
            if img(i,j)>128
                img(i,j)=255;
            else
                img(i,j)=0;
            end
        end
    end
end


function img = cropping(img)
    for i=1:size(img,1)
        if max(img(i,1:end))==255
            break;
        end
    end

    for i2=size(img,1):-1:1
        if max(img(i2,1:end))==255
            break;
        end
    end
    
    for j=1:size(img,2)
        if max(img(1:end,j))==255
            break;
        end
    end

    for j2=size(img,2):-1:1
        if max(img(1:end,j2))==255
            break;
        end
    end

    img=img(i:i2,j:j2);
end

function correct=iscorrect(points,x,correct)
    points = sortrows(points, 1);

    data = readmatrix(['.\Dataset\Coordinates\coord_' num2str(x) '.txt']);
    for i=1:size(points,1)
        if sqrt((points(i,2)-data(i,1))^2 + (points(i,3)-data(i,2))^2)>data(i,3)
            return;
        end
    end
    correct=correct+1;
end