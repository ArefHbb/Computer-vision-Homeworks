clc;clear;close all;

filter_size=21;
noise_percent=0.9;

I1=im2double(imread('Baboon.tif'));
I2=im2double(imread('Cameraman.tif'));
I3=im2double(imread('Peppers.tif'));
I4=im2double(imread('Street.bmp'));

%noise_image=noise_salt_pepper(I2,1);
renderImage(I1);
renderImage(I2);
renderImage(I3);
renderImage(I4);

function renderImage(img)
    kernel_size30=5;
    kernel_size50=7;
    kernel_size70=11;
    kernel_size90=39;

    imageNoise30=imnoise(img,'salt & pepper',0.3);
    myFilter30=mySoloution(imageNoise30,kernel_size30);
    matlabFilter30=medfilt2(imageNoise30,[kernel_size30,kernel_size30]);
    mypsnr30=mypsnr(img,myFilter30);
    matlabpsnr30=mypsnr(img,matlabFilter30);

    imageNoise50=imnoise(img,'salt & pepper',0.5);
    myFilter50=mySoloution(imageNoise50,kernel_size50);
    matlabFilter50=medfilt2(imageNoise50,[kernel_size50,kernel_size50]);
    mypsnr50=mypsnr(img,myFilter50);
    matlabpsnr50=mypsnr(img,matlabFilter50);

    imageNoise70=imnoise(img,'salt & pepper',0.7);
    myFilter70=mySoloution(imageNoise70,kernel_size70);
    matlabFilter70=medfilt2(imageNoise70,[kernel_size70,kernel_size70]);
    mypsnr70=mypsnr(img,myFilter70);
    matlabpsnr70=mypsnr(img,matlabFilter70);

    imageNoise90=imnoise(img,'salt & pepper',0.9);
    myFilter90=mySoloution(imageNoise90,kernel_size90);
    matlabFilter90=medfilt2(imageNoise90,[kernel_size90,kernel_size90]);
    mypsnr90=mypsnr(img,myFilter90);
    matlabpsnr90=mypsnr(img,matlabFilter90);

    figure
    subplot(2,2,1);
    imshow(myFilter30,[]);
    title(["30% => my: ", mypsnr30,", matlab: ", matlabpsnr30]);
    subplot(2,2,2);
    imshow(myFilter50,[]);
    title(["50% => my: ", mypsnr50,", matlab: ", matlabpsnr50]);
    subplot(2,2,3);
    imshow(myFilter30,[]);
    title(["70% => my: ", mypsnr70,", matlab: ", matlabpsnr70]);
    subplot(2,2,4);
    imshow(myFilter30,[]);
    title(["90% => my: ", mypsnr90,", matlab: ", matlabpsnr90]);
end


function output_img = mySoloution(img, filter_size)
    padded_img = padarray(img, [floor(filter_size/2) floor(filter_size/2)], 'replicate');
    
    output_img = zeros(size(img));
    
    for i = 1:size(img,1)
        for j = 1:size(img,2)
            if img(i,j)==0 || img(i,j)==1
                neighborhood = padded_img(i:i+filter_size-1, j:j+filter_size-1);
                
                median_val = median(neighborhood(:));
                
                output_img(i,j) = median_val;
            else
                output_img(i,j) = img(i,j);
            end
        end
    end
end




function psnr = mypsnr(original, fake)
    mse = mean(mean((double(original) - double(fake)).^2));
    max_pixel_val = 1;
    psnr = 10*log10(max_pixel_val^2/mse);
end




function image = noise_salt_pepper(image, n)
    num = size(image,1)*size(image,2)*n/100;
    for i=1:num/2
        x=randi([1,size(image,1)]);
        y=randi([1,size(image,2)]);
        image(x,y)=1;
    end
    for i=1:num/2
        x=randi([1,size(image,1)]);
        y=randi([1,size(image,2)]);
        image(x,y)=0;
    end
end