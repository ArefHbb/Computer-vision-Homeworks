clc;clear;close all;

key=rng;

I1=imread('image_1.tif');
J1=imread('image_2.tif');

I2=reshape(I1,[1,numel(I1)]);
I2=cat(2,bitget(I2,8),bitget(I2,7),bitget(I2,6),bitget(I2,5),bitget(I2,4),bitget(I2,3),bitget(I2,2),bitget(I2,1));

J2=J1-J1;
J2=reshape(J2,[1,numel(J2)]);
J2(1:size(I2,2))=I2;
J2=reshape(J2,size(J1));

random_pattern=(round(rand(size(J2))));
randomized_secret_message=xor(random_pattern,J2);
stego_image=bitset(J1,1,randomized_secret_message);
imshow(bitget(stego_image,1),[]);
figure,imshow((stego_image),[]);
imwrite(stego_image,'C:\Users\aref\Desktop\cv2\5\stego_image.tif');
save('C:\Users\aref\Desktop\cv2\5','key');



clc;clear;
load 'C:\Users\aref\Desktop\cv2\5'
I=imread('stego_image.tif');
rng(key);
random_pattern=(round(rand(size(I))));
lsb=bitget(I,1);
extract_secret_mesaage=xor(lsb,random_pattern);
extract_secret_mesaage=reshape(extract_secret_mesaage,[1,numel(extract_secret_mesaage)]);
extract_secret_mesaage=uint8(extract_secret_mesaage(1:2748768));

plane_size=size(extract_secret_mesaage,2)/8;
plane8=extract_secret_mesaage(1:plane_size);
plane7=extract_secret_mesaage(plane_size+1:2*plane_size);
plane6=extract_secret_mesaage(2*plane_size+1:3*plane_size);
plane5=extract_secret_mesaage(3*plane_size+1:4*plane_size);
plane4=extract_secret_mesaage(4*plane_size+1:5*plane_size);
plane3=extract_secret_mesaage(5*plane_size+1:6*plane_size);
plane2=extract_secret_mesaage(6*plane_size+1:7*plane_size);
plane1=extract_secret_mesaage(7*plane_size+1:8*plane_size);

J=zeros(1,plane_size);
J=bitset(J,8,plane8);
J=bitset(J,7,plane7);
J=bitset(J,6,plane6);
J=bitset(J,5,plane5);
J=bitset(J,4,plane4);
J=bitset(J,3,plane3);
J=bitset(J,2,plane2);
J=bitset(J,1,plane1);

final_image=uint8(reshape(J,[274,418,3]));

figure,imshow(final_image,[]);
