clc;clear;close all;

I=im2double(imread('sample.pgm'));
myGray2BW(I);
I=im2double(imread('sample.ppm'));
myRgb2BW(I);

function myGray2BW(I)
    J=I-I;
    J(I>0.5)=1;
    figure,imshow([I J]);
    title(['psnr: ' num2str(mypsnr(I,J))]);
    disp(num2str(mypsnr(I,J)));
end

function myRgb2BW(I)
    J=I-I;
    J(((I(:,:,1)+I(:,:,2)+I(:,:,3))/3)>0.5)=1;
    J=cat(3,J(:,:,1),J(:,:,1),J(:,:,1));
    psnr=mypsnr(I,J);
    figure,imshow([I J]);
    title(['psnr: ' num2str(mean(psnr(1,1,:)))]);
end

function psnr = mypsnr(original, fake)
    mse = mean(mean((double(original) - double(fake)).^2));
    max_pixel_val = 1;
    psnr = 10*log10(max_pixel_val^2/mse);
end