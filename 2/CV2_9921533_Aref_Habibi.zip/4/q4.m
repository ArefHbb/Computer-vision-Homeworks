clc;clear;close all;
tic;

I1=im2double(imread('Boat.png'));
I2=im2double(imread('Cameraman.tif'));
I3=im2double(imread('House.tif'));
I4=im2double(imread('Peppers.tif'));
I5=im2double(imread('LR_Boat.png'));
I6=im2double(imread('LR_Cameraman.tif'));
I7=im2double(imread('LR_House.tif'));
I8=im2double(imread('LR_Peppers.tif'));

all_soloution(I5,I1);
all_soloution(I6,I2);
all_soloution(I7,I3);
all_soloution(I8,I4);

toc;

function all_soloution(Input_Image,Original_Image)
    J_nearest = imresize(Input_Image, 2 * size(Input_Image), 'nearest');
    J_bilinear = imresize(Input_Image, 2 * size(Input_Image), 'bilinear');
    J_euclidean = imresize_Ed(Input_Image, 2);
    J_bicubic = imresize(Input_Image, 2 * size(Input_Image), 'bicubic');

    J_test = my_algorithm(J_nearest,J_bilinear,J_euclidean,J_bicubic);

    psnr_nearest=mypsnr(Original_Image,J_nearest);
    psnr_bilinear=mypsnr(Original_Image,J_bilinear);
    psnr_euclidean=mypsnr(Original_Image,J_euclidean);
    psnr_bicubic=mypsnr(Original_Image,J_bicubic);

    psnr_test=mypsnr(Original_Image,J_test);

    figure
    subplot(2,3,1);
    imshow(Original_Image);
    title('Original');
    subplot(2,3,2);
    imshow(J_nearest);
    title(['NN -> psnr: ' num2str(mean(psnr_nearest(1,1,:)))]);
    subplot(2,3,3);
    imshow(J_bilinear);
    title(['BL -> psnr: ' num2str(mean(psnr_bilinear(1,1,:)))]);
    subplot(2,3,4);
    imshow(J_euclidean);
    title(['ED -> psnr: ' num2str(mean(psnr_euclidean(1,1,:)))]);
    subplot(2,3,5);
    imshow(J_bicubic);
    title(['BC -> psnr: ' num2str(mean(psnr_bicubic(1,1,:)))]);
    subplot(2,3,6);
    imshow(J_bicubic);
    title(['My -> psnr: ' num2str(mean(psnr_test(1,1,:)))]);
end

function output_image = my_algorithm(J_nearest,J_bilinear,J_euclidean,J_bicubic)
    output_image=(2*J_nearest+11*J_bilinear+2*J_euclidean+5*J_bicubic)/20;
end

function Output_Image = imresize_Ed (Input_Image, Resizing_Factor)
    Output_Image=zeros(floor(size(Input_Image,1)*Resizing_Factor),floor(size(Input_Image,2)*Resizing_Factor),size(Input_Image,3));
    for i=1:size(Output_Image,1)
        for j=1:size(Output_Image,2)
            if floor(i/Resizing_Factor)+1 > size(Input_Image,1) || floor(j/Resizing_Factor)+1 > size(Input_Image,2)
                continue;
            end
            a=Input_Image(floor(i/Resizing_Factor)+1,floor(j/Resizing_Factor)+1,:);
            b=Input_Image(floor(i/Resizing_Factor)+1,ceil(j/Resizing_Factor),:);
            c=Input_Image(ceil(i/Resizing_Factor),floor(j/Resizing_Factor)+1,:);
            d=Input_Image(ceil(i/Resizing_Factor),ceil(j/Resizing_Factor),:);

            x=j/Resizing_Factor-floor(j/Resizing_Factor);
            y=i/Resizing_Factor-floor(i/Resizing_Factor);

            l1=sqrt(x^2+y^2);
            l2=sqrt((1-x)^2+y^2);
            l3=sqrt(x^2+(1-y)^2);
            l4=sqrt((1-x)^2+(1-y)^2);

            Output_Image(i,j,:)=(a*l1+b*l2+c*l3+d*l4)/(l1+l2+l3+l4);
        end
    end
end

function psnr = mypsnr(original, fake)
    mse = mean(mean((double(original) - double(fake)).^2));
    max_pixel_val = 1;
    psnr = 10*log10(max_pixel_val^2/mse);
end