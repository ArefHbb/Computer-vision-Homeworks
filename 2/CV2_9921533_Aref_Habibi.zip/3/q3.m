clc;clear;close all;

I=im2double(imread('Image_1.tif'));

I2=zeros(floor(size(I,1)/2),floor(size(I,2)/2),size(I,3));
for i=1:size(I2,1)
    for j=1:size(I2,2)
        I2(i,j,:)=I(i*2-1,j*2-1,:);
    end
end

J1=My_Imresize_1(I2,2);
J2=My_Imresize_2(I2,2);
J3=My_Imresize_3(I2,2);

psnr1=mypsnr(I,J1);
psnr2=mypsnr(I,J2);
psnr3=mypsnr(I,J3);

subplot(2,2,1);
imshow(I);
title('Original');
subplot(2,2,2);
imshow(J1);
title(['NN -> psnr: ' num2str(mean(psnr1(1,1,:)))]);
subplot(2,2,3);
imshow(J2);
title(['BL -> psnr: ' num2str(mean(psnr2(1,1,:)))]);
subplot(2,2,4);
imshow(J3);
title(['ED -> psnr: ' num2str(mean(psnr3(1,1,:)))]);


function Output_Image = My_Imresize_1 (Input_Image, Resizing_Factor)
    Output_Image=zeros(size(Input_Image,1)*Resizing_Factor,size(Input_Image,2)*Resizing_Factor,size(Input_Image,3));
    for i=1:size(Output_Image,1)
        for j=1:size(Output_Image,2)
            Output_Image(i,j,:)=Input_Image(round(i/Resizing_Factor),round(j/Resizing_Factor),:);
        end
    end
end

function Output_Image = My_Imresize_2 (Input_Image, Resizing_Factor)
    Output_Image=zeros(floor(size(Input_Image,1)*Resizing_Factor),floor(size(Input_Image,2)*Resizing_Factor),size(Input_Image,3));
    for i=1:size(Output_Image,1)
        for j=1:size(Output_Image,2)
            if floor(i/Resizing_Factor)+1 > size(Input_Image,1) || floor(j/Resizing_Factor)+1 > size(Input_Image,2)
                continue;
            end
            a=Input_Image(floor(i/Resizing_Factor)+1,floor(j/Resizing_Factor)+1,:);
            b=Input_Image(floor(i/Resizing_Factor)+1,ceil(j/Resizing_Factor),:);
            c=Input_Image(ceil(i/Resizing_Factor),floor(j/Resizing_Factor)+1,:);
            d=Input_Image(ceil(i/Resizing_Factor),ceil(j/Resizing_Factor),:);
            x=j/Resizing_Factor-floor(j/Resizing_Factor);
            y=i/Resizing_Factor-floor(i/Resizing_Factor);

            Output_Image(i,j,:)=a+(b-a)*x+(c-a)*y+(a-b-c+d)*x*y;
        end
    end
end

function Output_Image = My_Imresize_3 (Input_Image, Resizing_Factor)
    Output_Image=zeros(floor(size(Input_Image,1)*Resizing_Factor),floor(size(Input_Image,2)*Resizing_Factor),size(Input_Image,3));
    for i=1:size(Output_Image,1)
        for j=1:size(Output_Image,2)
            if floor(i/Resizing_Factor)+1 > size(Input_Image,1) || floor(j/Resizing_Factor)+1 > size(Input_Image,2)
                continue;
            end
            a=Input_Image(floor(i/Resizing_Factor)+1,floor(j/Resizing_Factor)+1,:);
            b=Input_Image(floor(i/Resizing_Factor)+1,ceil(j/Resizing_Factor),:);
            c=Input_Image(ceil(i/Resizing_Factor),floor(j/Resizing_Factor)+1,:);
            d=Input_Image(ceil(i/Resizing_Factor),ceil(j/Resizing_Factor),:);

            x=j/Resizing_Factor-floor(j/Resizing_Factor);
            y=i/Resizing_Factor-floor(i/Resizing_Factor);

            l1=sqrt(x^2+y^2);
            l2=sqrt((1-x)^2+y^2);
            l3=sqrt(x^2+(1-y)^2);
            l4=sqrt((1-x)^2+(1-y)^2);

            Output_Image(i,j,:)=(a*l1+b*l2+c*l3+d*l4)/(l1+l2+l3+l4);
        end
    end
end

function psnr = mypsnr(original, fake)
    mse = mean(mean((double(original) - double(fake)).^2));
    max_pixel_val = 1;
    psnr = 10*log10(max_pixel_val^2/mse);
end
