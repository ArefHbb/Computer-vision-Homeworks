clc;clear;close all;

image=im2double(imread('C:\Users\aref\Desktop\cv1\3\sample.ppm'));

degree=pi/8;

[Rows, Cols,depth] = size(image); 
Diagonal = sqrt(Rows^2 + Cols^2);
RowPad = ceil(Diagonal - Rows) + 2;
ColPad = ceil(Diagonal - Cols) + 2;
sizearr=Rows+RowPad;

imagepad = zeros(sizearr, sizearr,3);
imagepad(ceil(RowPad/2):(ceil(RowPad/2)+Rows-1),ceil(ColPad/2):(ceil(ColPad/2)+Cols-1),:) = image;

midx=ceil((size(imagepad,1)+1)/2);
midy=ceil((size(imagepad,2)+1)/2);

imagerot=zeros(size(imagepad));

for i=1:size(imagepad,1)
    for j=1:size(imagepad,2)
         x=round((i-midx)*cos(degree)-(j-midy)*sin(degree))+midx;
         y=round((i-midx)*sin(degree)+(j-midy)*cos(degree))+midy;

         if (x>=1 && y>=1 && x<=size(imagepad,2) && y<=size(imagepad,1))
              imagerot(i,j,:)=imagepad(x,y,:);
         end
    end
end

for i=1:size(imagerot,1)
    if max(imagerot(i,1:end))~=0
        break;
    end
end

for j=1:size(imagerot,1)
    if max(imagerot(1:end,j))~=0
        break;
    end
end

figure,imshow(imagerot(i:end-i,j:end-j,:));