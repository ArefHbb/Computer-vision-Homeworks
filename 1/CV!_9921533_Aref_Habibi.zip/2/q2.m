clc;clear;close all;

J=im2double(imread('C:\Users\aref\Desktop\cv1\2\sample.ppm'));
I=J;

for i=1:size(I,1)
    for j=1:size(I,2)
        if oval1(I,i,j) <= 1 && oval2(I,i,j) <= 1
            I(i,j,1)=1;
            I(i,j,2)=1;
            I(i,j,3)=1;
        elseif oval1(I,i,j) > 1 && oval2(I,i,j) <= 1
            I(i,j,1)=1-I(i,j,1);
            I(i,j,2)=1-I(i,j,2);
            I(i,j,3)=1-I(i,j,3);
        elseif oval1(I,i,j) > 1 && oval2(I,i,j) > 1
            avg = (I(i,j,1) + I(i,j,2) + I(i,j,3)) / 3;
            I(i,j,1)=avg;
            I(i,j,2)=avg;
            I(i,j,3)=avg;
        end
    end
end
finalimg = [I;J];
imwrite(finalimg,'C:\Users\aref\Desktop\cv1\2\finalimage.ppm')
imshow(finalimg,[]);

function o1 = oval1(I,x,y)
    o1 = ((x-size(I,1)/2)^2)/((800/2)^2) + ((y-size(I,2)/2)^2)/((400/2)^2);
end

function o2 = oval2(I,x,y)
    o2 = ((x-size(I,1)/2)^2)/((400/2)^2) + ((y-size(I,2)/2)^2)/((800/2)^2);
end