clc;clear;close all;

[image_data,format,width,height,maxgray] = imageRead('C:\Users\aref\Desktop\cv1\1\sample.pgm');
imageWrite('C:\Users\aref\Desktop\cv1\1\newsample.pgm',image_data,format,width,height,maxgray);

[image_data,format,width,height,maxgray] = imageRead('C:\Users\aref\Desktop\cv1\1\sample.ppm');
imageWrite('C:\Users\aref\Desktop\cv1\1\newsample.ppm',image_data,format,width,height,maxgray);

I1=imread('C:\Users\aref\Desktop\cv1\1\sample.ppm');
I2=imread('C:\Users\aref\Desktop\cv1\1\newsample.ppm');
I3=imread('C:\Users\aref\Desktop\cv1\1\sample.pgm');
I4=imread('C:\Users\aref\Desktop\cv1\1\newsample.pgm');

subplot(2,2,1);
imshow(I1,[]);
title("Original ppm");
subplot(2,2,2);
imshow(I2,[]);
title("New ppm");
subplot(2,2,3);
imshow(I3,[]);
title("Original pgm");
subplot(2,2,4);
imshow(I4,[]);
title("New pgm");

function [image_data,format,width,height,maxgray] = imageRead(imageAddr)
    f=fopen(imageAddr);
    file_content=fread(f,'uint8');
    fclose(f);
    
    format=char([file_content(1) file_content(2)]);
    
    z=4;
    width=0;
    while file_content(z)~=32
        width=width*10+file_content(z)-'0';
        z=z+1;
    end
    
    z=z+1;
    height=0;
    while file_content(z)~=32
        height=height*10+file_content(z)-'0';
        z=z+1;
    end

    z=z+1;
    maxgray=0;
    while file_content(z)~=10
        maxgray=maxgray*10+file_content(z)-'0';
        z=z+1;
    end
    
    if strcmp(format,'P5')==1
        depth=1;
    elseif strcmp(format,'P6')==1
        depth=3;
    end
    
    image_data=file_content(z+1:end);
    
    I=uint8(zeros(height,width,depth));
    z=1;
    for i=1:height
        for j=1:width
            for k=1:depth
                I(i,j,k)=image_data(z);
                z= z+1;
            end
        end
    end
end

function imageWrite(imageAddr,image_data,format,width,height,maxgray)
    file_content=[double(format) 32 double(num2str(width)) 32 double(num2str(height)) 32 double(num2str(maxgray)) 10 image_data']';
    f=fopen(imageAddr,'w');
    fwrite(f,file_content);
    fclose(f);
end





